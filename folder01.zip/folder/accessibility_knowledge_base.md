{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "metadata": {
    "title": "Comprehensive Accessibility & Digital Remediation Knowledge Base",
    "version": "3.0.0",
    "target_engines": ["RAG Vector Embeddings", "Chatbot System Context", "Automated Remediation Agent"],
    "supported_standards": [
      "WCAG 2.1 / 2.2 AA",
      "PDF/UA-1 (ISO 14289-1)",
      "PDF/UA-2 (ISO 14289-2)",
      "Matterhorn Protocol 1.1",
      "Section 508",
      "EN 301 549"
    ],
    "supported_tools": [
      "Adobe Acrobat Pro DC",
      "PAC (PDF Accessibility Checker 2024 / 2026)",
      "axesPDF",
      "CommonLook PDF",
      "Microsoft Word",
      "Microsoft PowerPoint",
      "Microsoft Excel",
      "NVDA",
      "JAWS"
    ]
  },

  "standards_and_protocols": {
    "wcag_2_2": {
      "focus": "Web Content Accessibility Guidelines applied to digital documents",
      "core_principles": ["Perceivable", "Operable", "Understandable", "Robust"],
      "critical_document_criteria": [
        {"id": "1.1.1", "name": "Non-text Content", "level": "A", "scope": "Images, vector graphics, formulas, decorative art"},
        {"id": "1.3.1", "name": "Info and Relationships", "level": "A", "scope": "Headings, lists, data tables, form relationships"},
        {"id": "1.3.2", "name": "Meaningful Sequence", "level": "A", "scope": "Logical tag tree reading order"},
        {"id": "1.4.3", "name": "Contrast (Minimum)", "level": "AA", "ratio": "4.5:1 regular text, 3:1 large text/UI components"},
        {"id": "2.4.2", "name": "Page Titled", "level": "A", "scope": "Document Title metadata and display properties"},
        {"id": "2.4.4", "name": "Link Purpose (In Context)", "level": "A", "scope": "Unambiguous anchor text and alternative descriptions"},
        {"id": "3.1.1", "name": "Language of Page", "level": "A", "scope": "Document-level primary language (/Lang)"},
        {"id": "3.1.2", "name": "Language of Parts", "level": "AA", "scope": "Inline span-level language switches"}
      ]
    },
    "pdf_ua_iso_14289": {
      "scope": "Universal Accessibility for PDF file format",
      "key_differences_from_wcag": [
        "Strict semantic container hierarchy (no generic Div where semantic tags exist)",
        "Mandatory embedding of all fonts with valid ToUnicode mapping tables",
        "Document title must be displayed in the application window bar",
        "All content must be categorized strictly as Real Content (tagged) or Artifact",
        "Interactive form fields must contain tooltips (/TU entry) and tab order set to Document Structure"
      ]
    },
    "matterhorn_protocol_1_1": {
      "definition": "31 checkpoints covering 136 failure conditions defining PDF/UA compliance",
      "categorization": {
        "machine_testable": "Automated checks validated directly by engines like PAC (89 failure conditions)",
        "human_testable": "Requires human operator inspection via structure views or screen readers (47 failure conditions)"
      }
    }
  },

  "pdf_semantic_tag_taxonomy": {
    "root_and_containers": {
      "Document": {
        "role": "Root container of the entire logical tag tree",
        "allowed_children": ["Part", "Art", "Sect", "Div", "H1-H6", "P", "Table", "L", "Figure"],
        "remediation_rule": "Must exist only once per document at top level. All tags must descend from Document."
      },
      "Part": {
        "role": "Major division container",
        "use_case": "Books, multi-chapter publications, or massive statutory volumes",
        "allowed_children": ["Art", "Sect", "Div", "H1", "P", "Table", "L"]
      },
      "Art": {
        "role": "Article container",
        "use_case": "Self-contained story or article, typical in magazine or journal layouts",
        "allowed_children": ["Sect", "Div", "H1-H6", "P", "Table", "L", "Figure"]
      },
      "Sect": {
        "role": "Section container",
        "use_case": "Standard sub-divisions within chapters or pages",
        "allowed_children": ["Sect", "Div", "H1-H6", "P", "Table", "L", "Figure"]
      },
      "Div": {
        "role": "Generic block-level division",
        "use_case": "Grouping related elements without assigning specific document semantics",
        "remediation_rule": "Avoid wrapping raw text directly into Div without inline semantic tags (P, Hx)."
      },
      "BlockQuote": {
        "role": "Long quotation set apart from normal body flow",
        "remediation_rule": "Should wrap one or more P tags containing the quoted material."
      },
      "Caption": {
        "role": "Descriptive title or caption for tables or figures",
        "allowed_parents": ["Table", "Figure"],
        "remediation_rule": "Must be the first or last child inside Table or Figure."
      }
    },
    "headings": {
      "H1_through_H6": {
        "role": "Structural document heading levels",
        "remediation_rule": "Must follow a strict hierarchical tree. No skipping levels (e.g., H1 followed directly by H3).",
        "empty_element_rule": "Empty heading tags (<H2></H2>) violate PDF/UA (Matterhorn 14-001) and must be purged or populated."
      },
      "H": {
        "role": "First-generation generic heading tag (PDF 1.4)",
        "remediation_rule": "Deprecated for modern PDF/UA. Map or convert all <H> tags to numbered <H1>-<H6>."
      }
    },
    "paragraphs_and_text": {
      "P": {
        "role": "Standard body paragraph element",
        "remediation_rule": "Cannot be used as empty spacing placeholders. Layout line breaks must be artifacted."
      },
      "Span": {
        "role": "Inline character formatting container",
        "use_case": "Used to attach alternate text (/ActualText), language overrides (/Lang), or expansion text (/E)",
        "remediation_rule": "Avoid unnecessary nested Span bloat. Consolidate adjacent Spans with identical properties."
      }
    },
    "lists": {
      "L": {
        "role": "List container element",
        "allowed_children": ["LI", "Caption", "Lbl"],
        "remediation_rule": "Must directly enclose <LI> elements. Unwrapped text or paragraph runs are strictly prohibited."
      },
      "LI": {
        "role": "List item element",
        "allowed_parents": ["L"],
        "allowed_children": ["Lbl", "LBody"],
        "remediation_rule": "Represents a single list entry. In strict PDF/UA, content goes inside LBody."
      },
      "Lbl": {
        "role": "Label element",
        "use_case": "Holds bullet glyphs, numbers, or alphanumeric enumeration strings",
        "remediation_rule": "Should contain solely the bullet or index character."
      },
      "LBody": {
        "role": "List item body element",
        "allowed_children": ["P", "Span", "Link", "L"],
        "remediation_rule": "Holds the actual content text. Sub-lists (nested <L>) MUST be placed inside the parent <LBody>."
      }
    },
    "tables": {
      "Table": {
        "role": "Data table container element",
        "allowed_children": ["Caption", "THead", "TBody", "TFoot", "TR"],
        "remediation_rule": "Prohibited for layout formatting. Layout tables must be flattened to linear P tags and artifacts."
      },
      "THead": { "role": "Table header row group container", "allowed_children": ["TR"] },
      "TBody": { "role": "Table body data row group container", "allowed_children": ["TR"] },
      "TFoot": { "role": "Table footer row group container", "allowed_children": ["TR"] },
      "TR": {
        "role": "Table row container element",
        "allowed_children": ["TH", "TD"],
        "remediation_rule": "Must not directly contain text runs without TH or TD cells."
      },
      "TH": {
        "role": "Table header cell",
        "attributes": ["/Scope (/Row, /Column, /Both)", "/ID"],
        "remediation_rule": "Every TH must have a defined Scope attribute. Complex multi-tier headers must define unique IDs."
      },
      "TD": {
        "role": "Table data cell",
        "attributes": ["/Headers (Array of IDs)", "/RowSpan", "/ColSpan"],
        "remediation_rule": "In complex tables, /Headers must explicitly point to the IDs of all applicable TH elements."
      }
    },
    "graphics_and_media": {
      "Figure": {
        "role": "Non-text graphical element (raster image, vector art, composite charts)",
        "attributes": ["/Alt (Alternative Text)", "/ActualText", "/BBox (Bounding Box)"],
        "remediation_rule": "Must contain meaningful /Alt attribute. If purely decorative, must be converted to an Artifact."
      },
      "Formula": {
        "role": "Mathematical or scientific equation",
        "attributes": ["/Alt"],
        "remediation_rule": "Must contain /Alt text with linear, human-spoken representation (e.g., 'f of x equals x squared')."
      }
    },
    "interactive_and_annotations": {
      "Link": {
        "role": "Hyperlink structure element",
        "structure": "Must contain the text marked content reference AND the Link Annotation Object Reference (OBJR)",
        "remediation_rule": "Orphaned link annotations not nested within a <Link> tag trigger immediate PDF/UA failure."
      },
      "Form": {
        "role": "Interactive form control wrapper",
        "structure": "Wraps interactive Widget Annotation OBJR",
        "remediation_rule": "The widget must contain a valid Tooltip (/TU key) defining the control's accessible name."
      }
    }
  },

  "pdf_architecture_and_deep_remediation": {
    "reading_order_vs_z_order_vs_content": {
      "logical_tag_tree": {
        "description": "Hierarchical XML-like tree inside the /StructTreeRoot dictionary of the PDF.",
        "assistive_tech_impact": "This is the ONLY source modern screen readers (NVDA, JAWS) use to determine document flow."
      },
      "order_panel_z_order": {
        "description": "Visual stacking and rendering order of drawing layers on the page canvas.",
        "common_misconception": "Adjusting the Acrobat 'Order Panel' only affects page drawing order and legacy reflow, NOT the tag tree."
      },
      "content_stream": {
        "description": "Low-level PDF operators (BT = Begin Text, ET = End Text, Do = Draw Object, re = Rectangle).",
        "remediation_use": "Used in Acrobat Content panel to trace path items, unlinked text runs, and create artifacts at operator level."
      }
    },
    "artifact_handling": {
      "artifact_definition": "Content that conveys no structural or semantic information (headers, footers, borders, watermarks).",
      "artifact_types": ["Pagination", "Layout", "Page", "Background"],
      "acrobat_remediation_steps": [
        "Select item in Touch Up Reading Order (TURO) tool -> Click 'Background/Artifact'.",
        "Or right-click tag in Tags Tree -> 'Change Tag to Artifact' -> Select type -> Delete remaining empty parent tag.",
        "Or open Content Panel -> Locate raw path/text run -> Right-click -> 'Create Artifact'."
      ]
    },
    "link_objr_architecture": {
      "diagram": "<Link> -> [Text Marked Content Run: 'Click Here'] + [OBJR: Link Annotation Dictionary]",
      "common_failure": "Visual text is tagged inside <Link>, but the interactive clickable box (OBJR) sits outside under <P>.",
      "remediation_steps": [
        "In Tags tree, expand <P> and <Link>.",
        "Locate the item with the small box/crosshair icon ('Link - /URI').",
        "Drag and drop this OBJR into the <Link> tag, positioning it immediately after the text content run."
      ]
    },
    "parent_tree_and_struct_parents": {
      "description": "The ParentTree maps low-level content items and annotations back to their corresponding nodes in the StructTree.",
      "broken_parent_tree_fix": "If PAC flags 'ParentTree missing entry' or 'Annotation not contained in ParentTree', use Acrobat Preflight -> 'Repair logical structure' or regenerate annotations using tools like axesPDF."
    }
  },

  "matterhorn_protocol_and_pac_error_catalog": {
    "errors": [
      {
        "matterhorn_code": "01-001",
        "pac_error_string": "Tagged content contains artifacts / Artifacts marked as real content",
        "category": "Real content and artifacts",
        "machine_testable": true,
        "root_cause": "An element enclosed in an /Artifact container is also referenced within the /StructTreeRoot (Tags Tree), or informational text is marked as an artifact.",
        "remediation_steps": {
          "acrobat_pro": [
            "In PAC, copy the Page Number and Element Object Number.",
            "Open file in Acrobat Pro -> Open Tags panel -> Options -> 'Find...'",
            "Select 'Unmarked Artifacts' or search by element ID.",
            "If an Artifact is inside the Tag Tree: Right-click the tag -> 'Delete Tag' (keeps artifacted drawing intact).",
            "If real text is erroneously artifacted: Open Content Panel -> Locate item -> Right-click -> 'Remove Artifact' -> Use Reading Order tool to tag as P or Hx."
          ],
          "axes_pdf": [
            "Select element in the logical tree view.",
            "Click 'Set as Artifact' button on ribbon.",
            "Execute automated 'Clear Empty Tags' cleanup."
          ]
        }
      },
      {
        "matterhorn_code": "09-001",
        "pac_error_string": "Link annotation is not nested inside a Link tag",
        "category": "Annotations",
        "machine_testable": true,
        "root_cause": "The interactive clickable link object (/Annot /Link) exists on the page canvas but is missing its corresponding OBJR wrapper inside the tag tree.",
        "remediation_steps": {
          "acrobat_pro": [
            "Open Acrobat Tags panel -> Options -> 'Find...'",
            "Set Search to 'Unmarked Annotations' -> Click 'Find Next'.",
            "When the link annotation is found, click 'Tag Element' -> Select Type: 'Link'.",
            "Move this new <Link> tag inside the appropriate parent paragraph (<P>).",
            "Ensure the anchor text content item is also inside this <Link> tag."
          ],
          "axes_pdf": [
            "Go to the 'Interactive Elements' panel.",
            "Click 'Fix Link Annotations'. axesPDF automatically links annotation objects to adjacent text."
          ]
        }
      },
      {
        "matterhorn_code": "10-001",
        "pac_error_string": "Character code cannot be mapped to Unicode / Missing ToUnicode mapping",
        "category": "Text / Fonts",
        "machine_testable": true,
        "root_cause": "Font embedded in the document lacks a /ToUnicode CMap table. Assistive technology receives invalid glyph indices instead of characters.",
        "remediation_steps": {
          "source_level": "Re-export document from original file (Word/InDesign). Ensure font embedding is checked ('Embed fonts in the file') and standard TrueType/OpenType fonts are used.",
          "acrobat_pro": [
            "Tools -> 'Scan & OCR' -> 'Recognize Text' -> 'In This File'.",
            "Settings: Set output to 'Searchable Image (Exact)' or 'Editable Text'.",
            "Run OCR. This generates a synthetic Unicode overlay mapping for unmapped glyphs.",
            "Alternatively, Tools -> Print Production -> Preflight -> 'PDF/UA compatibility' -> Run 'Synthesize Unicode mapping'."
          ]
        }
      },
      {
        "matterhorn_code": "13-001",
        "pac_error_string": "List element is not contained within a list container / List structure invalid",
        "category": "Lists",
        "machine_testable": true,
        "root_cause": "A List Item (<LI>) exists outside a List (<L>) container, or items other than <LI> (like raw <P>) are placed directly inside <L>.",
        "remediation_steps": {
          "acrobat_pro": [
            "In Tags panel, inspect the list structure.",
            "Create parent <L> tag if missing (Right-click -> New Tag -> Type: 'List').",
            "Ensure children of <L> are strictly <LI> tags.",
            "Ensure each <LI> tag contains exactly one <Lbl> (holding the bullet/number) and one <LBody> (holding text).",
            "If sub-lists exist, drag the nested <L> inside the preceding <LBody>."
          ]
        }
      },
      {
        "matterhorn_code": "14-001",
        "pac_error_string": "Heading levels are not consecutive / Non-standard heading order",
        "category": "Headings",
        "machine_testable": true,
        "root_cause": "Heading tags skip structural tiers (e.g., <H1> followed directly by <H3>, skipping <H2>).",
        "remediation_steps": {
          "acrobat_pro": [
            "In Tags panel, locate the skipped tag (<H3>).",
            "Right-click <H3> -> Select 'Properties'.",
            "In 'Tag' tab, change 'Type' dropdown from 'Heading Level 3' to 'Heading Level 2'.",
            "Alternatively, insert an intervening <H2> section header if appropriate for document hierarchy."
          ]
        }
      },
      {
        "matterhorn_code": "15-001",
        "pac_error_string": "Table header cell has no associated sub-elements or scope",
        "category": "Tables",
        "machine_testable": true,
        "root_cause": "<TH> tags lack the mandatory /Scope attribute (Row, Column, or Both) to tell screen readers which direction they label.",
        "remediation_steps": {
          "acrobat_pro": [
            "Open Tags panel -> Drill down to <Table> -> First <TR>.",
            "Select <TH> cell -> Right-click -> 'Table Cell Properties...'",
            "Verify radio button is set to 'Header Cell'.",
            "Under 'Scope' dropdown, select 'Column' (for vertical data columns) or 'Row' (for horizontal headers).",
            "Apply to all header cells in the row/column."
          ],
          "axes_pdf": [
            "Open 'Table Tool'.",
            "Click on header row -> Select 'Assign Column Scope' or 'Assign Row Scope' -> Apply to entire selection."
          ]
        }
      },
      {
        "matterhorn_code": "15-004",
        "pac_error_string": "Data cell is not associated with a header / Irregular table grid",
        "category": "Tables",
        "machine_testable": true,
        "root_cause": "Complex table with spanned or multi-tier headers has data cells (<TD>) that cannot resolve their parent header automatically.",
        "remediation_steps": {
          "acrobat_pro": [
            "Assign unique IDs to all <TH> elements: Right-click <TH> -> Properties -> Enter unique ID (e.g., 'H_Year', 'H_Revenue').",
            "Select target <TD> cells -> Right-click -> 'Table Cell Properties'.",
            "In 'Associated Header Cell IDs' panel, click '+' and add corresponding IDs ('H_Year', 'H_Revenue').",
            "For merged cells: Set RowSpan or ColSpan numbers to match the visual merge grid."
          ]
        }
      },
      {
        "matterhorn_code": "16-001",
        "pac_error_string": "Figure element has no alternate text / Missing /Alt entry",
        "category": "Graphics",
        "machine_testable": true,
        "root_cause": "<Figure> tag in logical structure tree lacks an /Alt string attribute or the string is empty.",
        "remediation_steps": {
          "acrobat_pro": [
            "Locate <Figure> in Tags panel.",
            "Right-click <Figure> -> Select 'Properties'.",
            "Under 'Alternative Text', input a succinct, informative description.",
            "If the figure is purely decorative: Cancel -> Right-click <Figure> tag -> 'Change Tag to Artifact...' -> Type: Layout -> Delete the <Figure> tag."
          ]
        }
      },
      {
        "matterhorn_code": "19-001",
        "pac_error_string": "Document title not set / Title entry in document information dictionary missing",
        "category": "Metadata",
        "machine_testable": true,
        "root_cause": "The document metadata lacks an explicit Title string in the XMP dictionary.",
        "remediation_steps": {
          "acrobat_pro": [
            "File -> Properties -> 'Description' tab.",
            "Enter descriptive name in the 'Title:' field (e.g., 'City Budget Report Fiscal Year 2026').",
            "Click OK -> Save Document."
          ]
        }
      },
      {
        "matterhorn_code": "19-002",
        "pac_error_string": "Document title not displayed in window title bar / ViewerPreferences missing DisplayDocTitle",
        "category": "Metadata / Initial View",
        "machine_testable": true,
        "root_cause": "The PDF ViewerPreferences dictionary /DisplayDocTitle flag is set to false or missing, causing viewer to show raw file name instead of title.",
        "remediation_steps": {
          "acrobat_pro": [
            "File -> Properties -> 'Initial View' tab.",
            "Under 'Window Options' group -> Locate 'Show:' dropdown.",
            "Change selection from 'File Name' to 'Document Title'.",
            "Click OK -> Save Document."
          ]
        }
      },
      {
        "matterhorn_code": "19-003",
        "pac_error_string": "PDF/UA identification missing / pdfuaid schema not present in XMP",
        "category": "Metadata / XMP",
        "machine_testable": true,
        "root_cause": "Document complies with structural rules but lacks the explicit pdfuaid:part='1' XMP namespace declaration.",
        "remediation_steps": {
          "acrobat_pro": [
            "Tools -> Print Production -> Preflight.",
            "Select 'PDF Standards' library -> Open 'PDF/UA'.",
            "Locate and run Fixup: 'Set PDF/UA-1 identifier'.",
            "Click 'Fix' -> Save as new file."
          ]
        }
      }
    ]
  },

  "authoring_remediation_playbooks": {
    "microsoft_word": {
      "rules": [
        {
          "area": "Headings",
          "correct_practice": "Apply Styles palette (Heading 1, Heading 2). Verify in View -> Navigation Pane.",
          "prohibited_practice": "Increasing font size, applying Bold or manual spacing to normal text runs.",
          "remediation_fix": "Select simulated heading text -> Click 'Heading 1' in Styles ribbon."
        },
        {
          "area": "Tables",
          "correct_practice": "Insert official Table -> Layout tab -> Check 'Repeat as header row at the top of each page'. Ensure 'Allow row to break across pages' is disabled.",
          "prohibited_practice": "Using tab keys or spacebars to align columns; nesting tables inside tables.",
          "remediation_fix": "Select Table -> Properties -> Alt Text tab -> Enter Title and Description."
        },
        {
          "area": "Images & Graphics",
          "correct_practice": "Wrap Text must be set to 'In Line with Text'.",
          "prohibited_practice": "Floating alignment ('Behind Text', 'In Front of Text', 'Square', 'Tight'). Floating images break reading order in PDF export.",
          "remediation_fix": "Select Image -> Layout Options -> Select 'In Line with Text' -> Right-click -> 'View Alt Text' -> Add functional text or check 'Mark as decorative'."
        },
        {
          "area": "Lists",
          "correct_practice": "Use standard Home ribbon Bulleted or Numbered list controls.",
          "prohibited_practice": "Typing hyphens, asterisks, or numbers manually.",
          "remediation_fix": "Highlight paragraphs -> Click 'Bullets' icon to convert into native list objects."
        },
        {
          "area": "Exporting to PDF",
          "prohibited_method": "File -> Print -> 'Microsoft Print to PDF' (Renders untagged, flat canvas with zero structure).",
          "recommended_method_1": "File -> Save As -> Choose 'PDF' -> Click 'Options...' -> Check 'Document structure tags for accessibility' and 'Create bookmarks using Headings'.",
          "recommended_method_2": "Acrobat Ribbon -> 'Create PDF' -> Preferences -> Enable 'Create Tagged PDF'."
        }
      ]
    },
    "microsoft_powerpoint": {
      "rules": [
        {
          "area": "Slide Layouts",
          "correct_practice": "Use predefined slide templates from View -> Slide Master (Title and Content, Two Content).",
          "prohibited_practice": "Starting with a blank slide and drawing freehand text boxes.",
          "remediation_fix": "Home ribbon -> Layout -> Select appropriate template. Transfer loose text into template placeholders."
        },
        {
          "area": "Slide Titles",
          "correct_practice": "Every slide must have a unique, non-empty Title.",
          "remediation_fix": "If design requires title to be visually absent: Review ribbon -> Check Accessibility -> Reading Order Pane -> Click slide title -> Select 'Hide Slide Title' (preserves programmatic name for screen readers while hiding visual render)."
        },
        {
          "area": "Reading Order Selection Pane",
          "critical_mechanic": "PowerPoint has TWO distinct order panes with different directions:",
          "details": [
            "Classic Selection Pane (Home -> Arrange -> Selection Pane): Evaluated from BOTTOM to TOP (lowest item in list reads first).",
            "Modern Reading Order Pane (Review -> Check Accessibility -> Reading Order Pane): Evaluated from TOP to BOTTOM (highest item reads first).",
            "Remediation rule: Use the Modern Reading Order Pane. Drag items into logical reading sequence."
          ]
        },
        {
          "area": "Complex Graphics & Diagrams",
          "correct_practice": "Select all shapes, lines, and text annotations -> Right-click -> Group (Ctrl+G).",
          "remediation_fix": "Assign Alt Text to the unified group container, preventing the screen reader from reading disjointed shapes."
        }
      ]
    },
    "microsoft_excel": {
      "rules": [
        {
          "area": "Table Formatting",
          "correct_practice": "Explicitly format data cells as an Excel Table: Select range -> Insert -> Table (Ctrl+T).",
          "remediation_fix": "Table Design ribbon -> Ensure 'Header Row' is checked. Give the table a distinct programmatic name."
        },
        {
          "area": "Sheet Architecture",
          "rules": [
            "Rename default sheet tabs (Sheet1, Sheet2) to distinct, descriptive names (e.g., 'Q3_Balance_Sheet').",
            "Park active cursor focus on Cell A1 in all sheets before saving.",
            "Do not use blank rows or columns to create visual spacing. Increase row heights or column widths instead."
          ]
        },
        {
          "area": "Charts",
          "correct_practice": "Right-click chart border -> Format Chart Area -> Size & Properties -> Alt Text -> Add Title & Description.",
          "accessibility_enhancement": "Always include an accessible data table adjacent to or below charts for screen reader consumption."
        }
      ]
    }
  },

  "chatbot_system_prompts_and_eval_harness": {
    "engine_persona": {
      "role": "Senior Accessibility Remediation Engineer & Digital Compliance Auditor",
      "tone": "Authoritative, technical, procedural, highly precise",
      "instruction": "Diagnose root causes referencing WCAG 2.1/2.2 and Matterhorn Protocol 1.1 failure numbers. Provide step-by-step instructions for Adobe Acrobat Pro, axesPDF, or source authoring tools (Word, PPT, Excel)."
    },
    "zero_shot_few_shot_examples": [
      {
        "query": "How do I fix empty heading tags flagged in PAC?",
        "response": {
          "standard_violation": "Matterhorn Protocol Checkpoint 14-001 (Empty heading element)",
          "cause": "A structural heading tag exists in the Tag Tree but contains no text, content items, or marked content references.",
          "procedure_acrobat": [
            "Open Tags Panel in Acrobat Pro.",
            "Click Options menu (top left of panel) -> Select 'Find...'",
            "Search for 'Empty Elements'.",
            "When the empty <H1>-<H6> tag is highlighted, right-click and choose 'Delete Tag'.",
            "Save and re-verify in PAC."
          ]
        }
      },
      {
        "query": "Why does PAC say 'Natural language of text run cannot be determined'?",
        "response": {
          "standard_violation": "Matterhorn Checkpoint 12-001 / WCAG 3.1.1 (Language of Document)",
          "cause": "The document Catalog dictionary lacks a /Lang entry, or an inline text segment in a foreign language lacks a localized /Lang override.",
          "procedure_acrobat": [
            "For full document: File -> Properties -> Advanced tab -> Reading Options -> Select primary language in 'Language' dropdown (e.g., 'English US' creates /Lang (en-US)).",
            "For inline foreign words: Select foreign word in Tags Tree -> Right-click -> Properties -> Tag tab -> Set 'Language' field to target ISO 639-1 code (e.g., 'fr-FR' or 'es-ES')."
          ]
        }
      }
    ]
  }
}