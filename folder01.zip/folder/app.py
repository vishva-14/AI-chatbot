import base64
import html
import os
import time
from google import genai
from google.genai import types
import streamlit as st

# ==============================================================================
# 🔑 1. API KEY SETUP
# ==============================================================================
GEMINI_API_KEY = "AQ.Ab8RN6IllhZR8o0P9JHM9BBZJO61T4IEpdlC1kUzzkJQzcdzKg"  # <--- Put your actual key here

st.set_page_config(
    page_title="Accessibility Assistant | HBS",
    page_icon="♿",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# Helper function to encode local logo as Base64 for the top navbar
def get_base64_image(image_path):
  if os.path.exists(image_path):
    with open(image_path, "rb") as img_file:
      return base64.b64encode(img_file.read()).decode()
  return None


logo_base64 = get_base64_image("logo.png")
logo_html_tag = (
    f'<img src="data:image/png;base64,{logo_base64}" class="brand-logo"'
    ' alt="HBS Logo" />'
    if logo_base64
    else '<div class="brand-fallback">HBS</div>'
)

# ==============================================================================
# 2. UI THEME
# ==============================================================================
CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Figtree:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    :root {
        --navy: #0A3A60;
        --navy-deep: #072B47;
        --azure: #0284C7;
        --paper: #F4F8FB;
        --card: #FFFFFF;
        --line: #D5E0EA;
        --text: #25364A;
        --muted: #61758A;
        --focus: #F5B700;
    }

    html, body, .stApp {
        font-family: 'Figtree', -apple-system, BlinkMacSystemFont, sans-serif;
        color: var(--text);
    }
    .stApp {
        background:
            radial-gradient(900px 380px at 12% -80px, rgba(2,132,199,0.11), transparent 70%),
            var(--paper) !important;
    }

    header, footer { visibility: hidden !important; height: 0 !important; }

    .block-container {
        padding-top: 1.4rem !important;
        padding-bottom: 8rem !important;
        max-width: 860px !important;
        margin: 0 auto !important;
    }

    /* ---------- Navbar ---------- */
    .luxury-navbar {
        display: flex;
        align-items: center;
        gap: 16px;
        background: var(--card);
        padding: 0 22px;
        border-radius: 16px;
        border: 1px solid var(--line);
        height: 58px;
        box-sizing: border-box;
    }
    .brand-logo { height: 32px; object-fit: contain; }
    .brand-fallback {
        font-family: 'Bricolage Grotesque', sans-serif;
        font-weight: 800; font-size: 20px; color: var(--navy); letter-spacing: -0.5px;
    }
    .navbar-divider { width: 1.5px; height: 24px; background: var(--line); }
    .navbar-title {
        font-family: 'Bricolage Grotesque', sans-serif;
        font-size: 1.08rem; font-weight: 700; color: var(--navy-deep); letter-spacing: -0.2px;
        white-space: nowrap;
    }
    .navbar-pills { margin-left: auto; display: flex; gap: 6px; }
    .pill {
        font-size: 0.72rem; font-weight: 600; color: var(--navy);
        background: #E8F1F8; border-radius: 999px; padding: 4px 10px;
        white-space: nowrap;
    }

    /* New chat button */
    .st-key-newchat button {
        background: var(--card) !important;
        color: var(--navy) !important;
        border: 1px solid var(--line) !important;
        border-radius: 14px !important;
        font-weight: 600 !important;
        font-size: 0.88rem !important;
        height: 58px !important;
        transition: border-color .15s ease, box-shadow .15s ease !important;
    }
    .st-key-newchat button:hover { border-color: var(--navy) !important; color: var(--navy-deep) !important; }

    /* ---------- Hero / Empty State ---------- */
    .hero { padding: 38px 4px 18px 4px; }
    .hero h1 {
        font-family: 'Bricolage Grotesque', sans-serif;
        font-weight: 800; font-size: 2.55rem; line-height: 1.08;
        letter-spacing: -1.2px; color: var(--navy-deep);
        margin: 0 0 14px 0; padding: 0; max-width: 620px;
    }
    .hero p {
        font-size: 1.04rem; line-height: 1.6; color: var(--muted);
        max-width: 600px; margin: 0 0 6px 0;
    }
    .hero-tip {
        display: inline-flex; align-items: center; gap: 10px;
        margin-top: 14px; font-size: 0.86rem; color: var(--text);
        background: #FFF8E1; border: 1px solid #F3DD9A; border-radius: 12px;
        padding: 9px 14px;
    }
    .hero-tip::before {
        content: ""; width: 10px; height: 10px; border-radius: 50%;
        background: var(--focus); flex-shrink: 0;
    }
    .chips-title {
        font-weight: 700; font-size: 0.95rem; color: var(--navy-deep);
        margin: 26px 0 10px 4px;
    }

    /* Suggested-question chips */
    .st-key-chips button {
        background: var(--card) !important;
        border: 1px solid var(--line) !important;
        border-radius: 14px !important;
        color: var(--text) !important;
        text-align: left !important;
        justify-content: flex-start !important;
        padding: 14px 16px !important;
        min-height: 64px !important;
        height: auto !important;
        font-size: 0.92rem !important;
        font-weight: 500 !important;
        line-height: 1.4 !important;
        transition: border-color .15s ease, transform .15s ease !important;
    }
    .st-key-chips button:hover {
        border-color: var(--navy) !important;
        color: var(--navy-deep) !important;
        transform: translateY(-1px);
    }
    .st-key-chips button p { text-align: left !important; margin: 0 !important; }

    /* ---------- User message ---------- */
    .user-container {
        display: flex; justify-content: flex-end; align-items: flex-end;
        gap: 10px; margin: 6px 0 22px 0; width: 100%;
    }
    .user-bubble {
        background: linear-gradient(135deg, var(--navy) 0%, var(--navy-deep) 100%);
        color: #FFFFFF;
        padding: 13px 20px;
        border-radius: 18px 18px 4px 18px;
        max-width: 80%;
        font-size: 0.95rem; line-height: 1.55;
        word-break: break-word; white-space: pre-wrap;
    }
    .user-avatar {
        width: 32px; height: 32px; background: var(--navy); color: #fff;
        border-radius: 50%; display: flex; align-items: center; justify-content: center;
        font-size: 0.66rem; font-weight: 700; flex-shrink: 0;
    }

    /* ---------- Assistant card ---------- */
    div[data-testid="stChatMessage"] {
        background: var(--card) !important;
        border: 1px solid var(--line) !important;
        border-radius: 18px !important;
        padding: 22px 26px 18px 26px !important;
        margin-bottom: 22px !important;
        width: 100% !important;
    }
    div[data-testid="stChatMessage"] div[data-testid="stChatMessageAvatar"] { display: none !important; }
    div[data-testid="stChatMessage"] div[data-testid="stChatMessageContent"] {
        padding: 0 !important; margin: 0 !important; width: 100% !important;
    }

    /* STRICT SINGLE-LINE BOT HEADER */
    .bot-head {
        display: flex !important;
        flex-direction: row !important;
        align-items: center !important;
        gap: 10px !important;
        margin-bottom: 12px !important;
        white-space: nowrap !important;
    }
    .bot-badge {
        width: 26px; height: 26px; border-radius: 7px;
        background: var(--navy); color: #fff;
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 0.75rem; font-weight: 700;
        box-shadow: 0 0 0 2px var(--card), 0 0 0 4px var(--focus);
        flex-shrink: 0;
    }
    .bot-name {
        color: var(--navy-deep) !important;
        font-weight: 700 !important;
        font-size: 0.96rem !important;
        display: inline-block !important;
        white-space: nowrap !important;
    }

    /* Typography inside answers */
    div[data-testid="stChatMessage"] h4 {
        font-family: 'Bricolage Grotesque', sans-serif !important;
        color: var(--navy) !important;
        font-weight: 700 !important;
        font-size: 1.05rem !important;
        letter-spacing: -0.2px;
        margin: 22px 0 10px 0 !important;
        padding: 16px 0 0 0 !important;
        border-top: 1px solid var(--line);
    }
    div[data-testid="stChatMessage"] h4:first-of-type { border-top: none; margin-top: 8px !important; padding-top: 0 !important; }
    div[data-testid="stChatMessage"] strong { color: #0F2236 !important; }
    div[data-testid="stChatMessage"] p,
    div[data-testid="stChatMessage"] li {
        line-height: 1.7 !important; color: var(--text) !important; font-size: 0.95rem !important;
    }
    div[data-testid="stChatMessage"] ul, div[data-testid="stChatMessage"] ol {
        margin-left: 18px !important; margin-bottom: 12px !important;
    }
    div[data-testid="stChatMessage"] li::marker { color: var(--azure); font-weight: 700; }

    /* Inline code / tag pills (e.g., <Table>, <TR>, /Scope) */
    div[data-testid="stChatMessage"] :not(pre) > code {
        font-family: 'JetBrains Mono', monospace !important;
        font-size: 0.85rem !important;
        background: #E8F1F8 !important;
        color: var(--navy-deep) !important;
        border-radius: 6px !important;
        padding: 2px 7px !important;
        font-weight: 500 !important;
    }

    /* Outer dark terminal container */
    div[data-testid="stChatMessage"] pre {
        background: #081D33 !important;
        background-color: #081D33 !important;
        border: 1px solid #1E3A58 !important;
        border-radius: 12px !important;
        padding: 16px 20px !important;
        margin: 14px 0 !important;
        overflow-x: auto !important;
    }

    /* Force all inner wrappers/code to be transparent with crisp, readable white text */
    div[data-testid="stChatMessage"] pre,
    div[data-testid="stChatMessage"] pre * {
        background: transparent !important;
        background-color: transparent !important;
        color: #F8FAFC !important;
        font-family: 'JetBrains Mono', 'Consolas', monospace !important;
        font-size: 0.88rem !important;
        line-height: 1.6 !important;
        letter-spacing: 0.3px !important;
        text-shadow: none !important;
    }

    /* Tables */
    div[data-testid="stChatMessage"] table { border-collapse: collapse; width: 100%; font-size: 0.9rem; margin: 12px 0; }
    div[data-testid="stChatMessage"] th { background: #EAF2F9; color: var(--navy-deep); text-align: left; }
    div[data-testid="stChatMessage"] th, div[data-testid="stChatMessage"] td {
        border: 1px solid var(--line); padding: 8px 12px;
    }

    /* Spinner */
    div[data-testid="stSpinner"] { color: var(--muted); font-weight: 500; padding: 4px 4px 12px 4px; }

    /* ---------- Input bar ---------- */
    div[data-testid="stBottom"] > div { background: linear-gradient(180deg, rgba(244,248,251,0) 0%, var(--paper) 38%) !important; }
    div[data-testid="stChatInput"] { max-width: 860px !important; margin: 0 auto !important; padding: 0 !important; }
    div[data-testid="stChatInput"] > div {
        border-radius: 999px !important;
        background-color: var(--card) !important;
        border: 1.5px solid var(--line) !important;
        padding: 4px 10px !important;
        transition: box-shadow .15s ease, border-color .15s ease !important;
    }
    div[data-testid="stChatInput"] > div:focus-within {
        border-color: var(--navy) !important;
        box-shadow: 0 0 0 3px var(--paper), 0 0 0 6px var(--focus) !important;
    }
    div[data-testid="stChatInput"] textarea { color: #1E293B !important; font-size: 0.95rem !important; font-family: 'Figtree', sans-serif !important; }
    div[data-testid="stChatInput"] button { background: var(--navy) !important; color: #fff !important; border-radius: 50% !important; }
    div[data-testid="stChatInput"] button:hover { background: var(--azure) !important; }

    @media (max-width: 720px) {
        .navbar-pills { display: none; }
        .hero h1 { font-size: 1.9rem; }
        .user-bubble { max-width: 90%; }
        div[data-testid="stChatMessage"] { padding: 18px 16px 14px 16px !important; }
    }
    @media (prefers-reduced-motion: reduce) {
        * { transition: none !important; }
        .st-key-chips button:hover { transform: none !important; }
    }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

# ==============================================================================
# 3. KNOWLEDGE BASE LOADING & SYSTEM PROMPT
# ==============================================================================
KB_PATH = "accessibility_knowledge_base.md"
if os.path.exists(KB_PATH):
  with open(KB_PATH, "r", encoding="utf-8") as f:
    kb_content = f.read()
else:
  kb_content = (
      "Standard PDF/UA-1, Matterhorn Protocol 1.1, WCAG 2.2 AA, and Microsoft"
      " Office accessibility guidelines apply."
  )

SYSTEM_PROMPT = f"""You are "Accessibility Assistant", an expert diagnostic accessibility remediation specialist representing Hudsmer Business Solutions (HBS).

Your domain is strictly document and digital accessibility: PDF/UA (ISO 14289), WCAG 2.1/2.2 AA, Matterhorn Protocol 1.1, PAC 2026 / PAC 2024, Adobe Acrobat Pro, axesPDF, CommonLook, and Microsoft Office (Word, PowerPoint, Excel).

==================================================
KNOWLEDGE BASE:
{kb_content}
==================================================

CRITICAL OPERATING RULES:

1. OUT-OF-SCOPE / GENERAL QUERIES (Weather, News, Celebrities, General Coding, Trivia):
   - Do NOT produce the 4-part diagnosis structure for out-of-scope topics.
   - Reply briefly and politely in 1-2 conversational sentences:
     "I am an Accessibility Assistant representing Hudsmer Business Solutions (HBS), specialized exclusively in digital and document accessibility remediation (PDF/UA, WCAG, and Office documents). I cannot answer general queries like weather or news. Please let me know if you need help resolving an accessibility error."

2. VISUAL TAG TREES & STRUCTURE QUERIES:
   - When asked for a structure (such as tag trees, list hierarchies, table structures, or reading order):
     ALWAYS provide an explicit visual ASCII tree or code block. Do NOT just explain it in continuous prose.
     Example:
     ```
     <Document>
       ├── <H1>
       ├── <P>
       └── <L>
           ├── <LI>
           │    ├── <Lbl>
           │    └── <LBody>
     ```

3. ACCESSIBILITY ISSUES & REMEDIATION (Normal Workflow):
   Provide exact click paths (e.g., Tags Panel -> <Table> -> <TR> -> Properties -> Table tab -> Scope -> Column) and strictly format the answer using these markdown headings:
   #### 1. Technical Diagnosis
   #### 2. Exact Remediation Steps (Click-by-Click)
   #### 3. Verification & Validation
   #### 4. Source Prevention (Authoring Fix)

4. DO NOT OUTPUT ANY HTML TAGS (such as <div>, <span>, or class attributes). Output clean standard Markdown only.
"""


# ==============================================================================
# 4. ENGINE CLIENT & AUTOMATIC MODEL SELECTION
# ==============================================================================
@st.cache_resource
def get_genai_client():
  return genai.Client(api_key=GEMINI_API_KEY)


def get_available_models(client):
  preferred = [
      "gemini-2.5-flash",
      "gemini-2.5-flash-lite",
      "gemini-2.0-flash",
      "gemini-1.5-flash",
      "gemini-3.5-flash-lite",
      "gemini-3.1-flash-lite",
  ]
  try:
    supported = [
        m.name.replace("models/", "")
        for m in client.models.list()
        if "generateContent" in getattr(m, "supported_actions", [])
    ]
    active = [m for m in preferred if m in supported]
    if not active:
      active = [m for m in supported if "flash" in m]
    return active if active else ["gemini-2.0-flash", "gemini-1.5-flash"]
  except Exception:
    return ["gemini-2.0-flash", "gemini-1.5-flash"]


def get_or_create_chat():
  if "genai_client" not in st.session_state:
    st.session_state.genai_client = get_genai_client()

  if "active_models" not in st.session_state:
    st.session_state.active_models = get_available_models(
        st.session_state.genai_client
    )

  if (
      "chat_session" not in st.session_state
      or st.session_state.chat_session is None
  ):
    chosen_model = st.session_state.active_models[0]
    st.session_state.chat_session = st.session_state.genai_client.chats.create(
        model=chosen_model,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            temperature=0.2,
        ),
    )
  return st.session_state.chat_session


def send_with_fallback(chat, prompt):
  client = st.session_state.genai_client
  models_to_try = st.session_state.active_models

  for model_name in models_to_try:
    for attempt in range(1, 4):
      try:
        return chat.send_message(prompt).text
      except Exception as e:
        err = str(e)
        if "503" in err or "429" in err or "high demand" in err.lower():
          time.sleep(attempt * 1.5)
        else:
          break

    try:
      chat = client.chats.create(
          model=model_name,
          config=types.GenerateContentConfig(
              system_instruction=SYSTEM_PROMPT,
              temperature=0.2,
          ),
      )
      st.session_state.chat_session = chat
      return chat.send_message(prompt).text
    except Exception:
      continue

  raise RuntimeError(
      "All Gemini models are momentarily busy. Please try again in a few"
      " seconds."
  )


# ==============================================================================
# 5. CONVERSATION STATE INITIALIZATION
# ==============================================================================
if "messages" not in st.session_state:
  st.session_state.messages = [{
      "role": "assistant",
      "content": (
          "I am your **Accessibility Assistant**. I specialize in document and"
          " digital accessibility compliance across **PDF/UA**, **Adobe"
          " Acrobat Pro**, **PAC 2026**, **WCAG 2.1/2.2 AA**, **Word**,"
          " **PowerPoint**, and **Excel**.\n\nPlease ask any question or"
          " describe the accessibility error you are facing."
      ),
  }]

# ==============================================================================
# 6. NAVBAR
# ==============================================================================
col_nav, col_btn = st.columns([7.8, 2.2])

with col_nav:
  st.markdown(
      f"""
    <div class="luxury-navbar">
        {logo_html_tag}
        <div class="navbar-divider"></div>
        <div class="navbar-title">Accessibility Assistant</div>
        <div class="navbar-pills">
            <span class="pill">PDF/UA</span>
            <span class="pill">WCAG 2.2</span>
            <span class="pill">Matterhorn 1.1</span>
        </div>
    </div>
    """,
      unsafe_allow_html=True,
  )

with col_btn:
  with st.container(key="newchat"):
    if st.button("New chat", use_container_width=True):
      st.session_state.messages = [{
          "role": "assistant",
          "content": (
              "Started a fresh conversation session. How can I assist with"
              " your document remediation?"
          ),
      }]
      st.session_state.chat_session = None
      st.rerun()

# ==============================================================================
# 7. WELCOME SCREEN OR CHAT HISTORY
# ==============================================================================
SUGGESTIONS = [
    "PAC says my table has no header cells. How do I fix it?",
    "Show me the tag tree structure for a nested list in PDF.",
    "The reading order in my PDF is scrambled. Where do I fix it?",
    "Link annotations are not nested in the tag tree. What now?",
    "My PowerPoint export has the wrong reading order. How do I fix it?",
    "Show me the structure of an accessible table in PDF.",
]

if "pending_prompt" not in st.session_state:
  st.session_state.pending_prompt = None

if len(st.session_state.messages) == 1:
  st.markdown(
      """
    <div class="hero">
        <h1>What is PAC flagging in your document?</h1>
        <p>Describe the error and the tool you are using. You get click-by-click
        fixes for the tag tree, the Acrobat panels, and the Word, PowerPoint or
        Excel source file.</p>
        <div class="hero-tip">Include the Matterhorn code or PAC message for the most precise fix.</div>
    </div>
    <div class="chips-title">Start with a common problem</div>
    """,
      unsafe_allow_html=True,
  )
  with st.container(key="chips"):
    for i in range(0, len(SUGGESTIONS), 2):
      c1, c2 = st.columns(2)
      with c1:
        if st.button(SUGGESTIONS[i], key=f"chip_{i}", use_container_width=True):
          st.session_state.pending_prompt = SUGGESTIONS[i]
      with c2:
        if st.button(
            SUGGESTIONS[i + 1], key=f"chip_{i + 1}", use_container_width=True
        ):
          st.session_state.pending_prompt = SUGGESTIONS[i + 1]
else:
  st.markdown("<div style='height:18px'></div>", unsafe_allow_html=True)
  for msg in st.session_state.messages:
    if msg["role"] == "user":
      st.markdown(
          f"""
            <div class="user-container">
                <div class="user-bubble">{html.escape(msg['content'])}</div>
                <div class="user-avatar">YOU</div>
            </div>
            """,
          unsafe_allow_html=True,
      )
    else:
      with st.chat_message("assistant"):
        st.markdown(
            '<div class="bot-head"><div class="bot-badge">A</div><span'
            ' class="bot-name">Accessibility Assistant</span></div>',
            unsafe_allow_html=True,
        )
        st.markdown(msg["content"])

# ==============================================================================
# 8. QUERY INPUT & EXECUTION
# ==============================================================================
prompt_input = st.chat_input(
    "Ask any accessibility question (e.g., Matterhorn 15-001 error, Link"
    " annotations, PowerPoint reading order...)"
)

if not prompt_input and st.session_state.pending_prompt:
  prompt_input = st.session_state.pending_prompt
  st.session_state.pending_prompt = None

if prompt_input:
  st.session_state.messages.append({"role": "user", "content": prompt_input})
  chat = get_or_create_chat()

  with st.spinner("Analyzing document structure & compliance standards..."):
    try:
      raw_text = send_with_fallback(chat, prompt_input)
    except Exception as e:
      raw_text = f"⚠️ Error generating response: {e}"

    clean_text = raw_text
    if "<div" in clean_text:
      clean_text = clean_text.split("<div")[0].strip()
    if "[REFERENCED:" in clean_text:
      clean_text = clean_text.split("[REFERENCED:")[0].strip()

    st.session_state.messages.append(
        {"role": "assistant", "content": clean_text}
    )
    st.rerun()